## Interface tests

All the interface classes inherit from this class, meaning that tests will be converted in the exchanges' folder.