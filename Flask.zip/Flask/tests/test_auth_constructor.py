import unittest


class TestAuthConstructor(unittest.TestCase):
    pass
