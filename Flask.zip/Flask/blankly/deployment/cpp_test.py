from blankly.deployment.hello import hello


if __name__ == "__main__":
    print("before")
    print(hello("wassup"))
    print("after")