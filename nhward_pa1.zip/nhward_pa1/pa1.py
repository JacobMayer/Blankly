'''

AUTHOR   : Nicholas Ward
NET_ID   : nhward
CLASS    : CS 457
DATE     : 02/24/22

'''


#allows us to do file and directory operations in python
import os
#so that we can split the text nicely 
from cv2 import split


#create the database class to keep things organized and hopfully help later down the road on different projects. 
class Database():
    def __init__(self):
        '''
        
        self.database_name   : points to the database that the user wants to use
        self.database_table  : points to the table in the database that the user wants to use
        
        '''

        self.database_name = ''
        self.database_table = ''


    #creates a database with the name that the user wants
    def create_database(self, database_name):
        #checks to see if the path exists to the database
        if not os.path.exists(database_name):
            #Makes the folder according to the users database name
            os.makedirs(database_name)
            return True
        else:
            return False
    
    #delete the database that the user wants to delete
    def drop_database(self, database_name):
        #check to see if the directory to the database exists
        if os.path.exists(database_name):
            #removes the folder of the database according to the database name
            os.rmdir(database_name)
            return True
        else:
            return False

    #function to point to the correct database that the user wants to use
    def use_database(self, database_name):
        #Checks to see if the directory exists to the database.
        if os.path.exists(database_name):
            return True
        else:
            return False

    #function to create a table and insert information that the user wants into the text file
    def create_table(self, table_name, list_array):
        '''
        table_name            : The name of the text file that the user wants
        list_array            : a list of the information that the user wants inserted into the text
        table_dir             : the directory of the table text file
        self.database_table   : points to the correct directory of the table text file so that other functions can use this variable
        double_counter        : a counter to check when the for loop has ran at a multiple of two to go to next line.
        '''

        table_dir = self.database_name + '/' + table_name + '.txt'
        self.database_table = table_name
        double_counter = 1
        
        #checks to make sure that the table file exists. 
        if os.path.exists(table_dir):
            return True
        else: 
            #if it doesn't exist then we create a new file with the given name from user and input in the information that they specified...

            with open(table_dir, 'w') as fp:
                for i in list_array:
                    if double_counter % 2 == 0:
                        fp.write(i)
                        fp.write('\n')
                    else:
                        fp.write(i + " ")
                        
                    double_counter += 1           

            return False
    
    #function to detete the table that the use inputs
    def delete_table(self, table_name):
        table_dir = self.database_name + '/' + table_name + '.txt'
        if os.path.exists(table_dir):
            #library function to remove the text file that the user specified
            os.remove(table_dir)
            return True
        else:
            return False

    #function to print out the table contents. 
    def show_table(self, table_name):

        '''
        table_dir       : The directory of the table text file
        text_lines      : a list to hold each line in the file as a string 
        length          : a variable to hold the length of the list ie. the amount of elements in the list
        counter         : a counter variable to tell us when we have reached the last line so we don't print an extra '|'.
        fixed_line      : the new line string that take away the new line character ('\n') so that we don't get a new line when printing the strings
        
        '''

        table_dir = self.database_name + '/' + table_name + '.txt'
        
        if os.path.exists(table_dir):
            #opens the table text file as read only so we can't change anything in the text file
            with open(table_dir, 'r') as fp:

                text_lines = fp.readlines()
                length = len(text_lines)
                counter = 1

                print('--', end = ' ')
                for i in text_lines:
                    fixed_line = i.replace('\n', '')
                    if counter == length:
                        print(fixed_line)
                    else:
                        print(fixed_line, end=' ')
                        print(' | ', end = '')
                    counter += 1

            return True
        else:
            return False

    
    def add_to_table(self, add_list):
        table_dir = self.database_name + '/' + self.database_table + '.txt'
        counter = 1
        if os.path.exists(table_dir):
            with open(table_dir, 'a') as fp:
                
                for i in add_list:
                    if counter % 2 == 0:
                        fp.write(i)
                        fp.write('\n')
                    else:
                        fp.write(i + ' ')
                

            return True
        else:
            return False
    


    def main_run(self):

        '''
        
        end_program         : variable for user input
        split_input         : list to hold the split strings of the user input
        length_input        : holds the length or number of elements that is in the split_input list. 
        bool                : a true or false variable that will say whether or now the action was completed or not
        
        '''

        end_program = False

        #loops the program so that the user can enter commands until the 
        while end_program == False:
            #allows for user input
            user_input = input()
            split_input = user_input.split()
            length_input = len(split_input)           

            if length_input == 3:
                if split_input[0] == 'CREATE' and split_input[1] == 'DATABASE':
                    #replace function gets rid of the ';' character 
                    split_input[2] = split_input[2].replace(';', '')

                    bool = self.create_database(split_input[2])
                    
                    if bool == False:
                        print ('-- !Failed to create database ', split_input[2], ' because it already exists')
                    else:
                        print('-- Database ', split_input[2], ' created')
                elif split_input[0] == 'DROP' and split_input[1] == 'DATABASE':
                    split_input[2] = split_input[2].replace(';', '')
                    bool = self.drop_database(split_input[2])
                    if bool == False:
                        print('-- !Failed to delete database', split_input[2], ' because it does not exist.')
                    else:
                        print('-- Database ', split_input[2], ' deleted.')
                elif split_input[0] == 'DROP' and split_input[1] == 'TABLE':
                    split_input[2] = split_input[2].replace(';', '')
                    bool = self.delete_table(split_input[2])
                    if bool == True:
                        print('-- Table ', self.database_table, ' deleted.')
                    else:
                        print('-- !Failed to delete table ', self.database_table, ' because it does not exist.')

            if length_input == 4:
                split_input[3] = split_input[3].replace(';', '')

                if split_input[0] == 'SELECT' and split_input[1] == '*' and split_input[2] == 'FROM':
                    bool = self.show_table(split_input[3])

                    if bool == False: 
                        print('-- !Failed to query table ', split_input[3], ' because it does not exist.')

            if length_input == 6:
                split_input[5] = split_input[5].replace(';', '')

                if split_input[0] == 'ALTER' and split_input[1] == 'TABLE' and split_input[3] == 'ADD':
                    self.database_table = split_input[2]
                    input_list = [split_input[4], split_input[5]]
                    bool = self.add_to_table(input_list)

                    if bool == True:
                        print('-- Table ', self.database_table, ' modified.')
                    else:
                        print('-- !Failed to alter table ', self.database_table)

            if length_input == 7:
                split_input[3] = split_input[3].replace('(', '')
                split_input[4] = split_input[4].replace(',', '')
                split_input[6] = split_input[6].replace(');', '')

                list_array = [split_input[3], split_input[4], split_input[5],split_input[6]]

                if split_input[0] == 'CREATE' and split_input[1] == 'TABLE':
                    bool = self.create_table(split_input[2], list_array)
                    if bool == True:
                        print('-- !Failed to create table ', split_input[2], ' because it already exists.')
                    else:
                        print('Table ', split_input[2], ' created.')
                
            if split_input[0] == 'USE':
                split_input[1] = split_input[1].replace(';', '')
                bool = self.use_database(split_input[1])
                if bool == False:
                    print('-- !Failed to locate ', split_input[1])
                else:
                    print('-- Using database ', split_input[1])
                    self.database_name = split_input[1]
            elif user_input == '.EXIT':
                print('-- All done.')
                break

if __name__ == '__main__':
    database = Database()
    database.main_run()
